# UTClock
Simple UTC Clock for developer. It runs on your Mac OS X menu bar or Windows Task bar

![UTClock Screenshot](screenshot.png "UTClock Screenshot")

## Setup

    # install packages
    npm install

    # build app
    npm run build

    # start app without building
    npm start
